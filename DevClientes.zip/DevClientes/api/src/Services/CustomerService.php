<?php
declare(strict_types=1);
require_once __DIR__ . '/../Models/Customer.php';
require_once __DIR__ . '/../Repositories/CustomerRepository.php';
require_once __DIR__ . '/../Utils/Validation.php';

class CustomerService {
    public function create(array $data): bool {
        $customerRepository = new CustomerRepository;
        $customer = new Customer(
            null,
            Validate::name($data['name']),
            Validate::email($data['email']),
            Validate::role($data['role']),
            isset($data['status']) ? 1 : 0
        );
        return $customerRepository->insert($customer);
    }
}

?>