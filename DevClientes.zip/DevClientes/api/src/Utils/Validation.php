<?php
declare(strict_types=1);
require_once __DIR__ . '/Normalization.php';

class Validate {

    public static function name() {
    }

    public static function email(string $email): ?string {
        return Normalize::format($email, Type::EMAIL);
    }

    public static function role(string $role) {
    }
}

?>