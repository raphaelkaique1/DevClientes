<?php
declare(strict_types=1);
setlocale(LC_ALL, 'pt-BT');

enum Type {
    case EMAIL;
    case NAME;
};

class Normalize {
    public static function format(string $text, Type $type): string|bool {
        $text = strtolower($text);
        return match($type) {
            Type::EMAIL => filter_var($text, FILTER_VALIDATE_EMAIL) && filter_var($text, FILTER_SANITIZE_EMAIL),
            Type::NAME  => ctype_alpha($text) && ucwords($text)
        };
    }

}

?>